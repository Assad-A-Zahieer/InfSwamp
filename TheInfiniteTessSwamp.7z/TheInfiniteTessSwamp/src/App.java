import java.util.Random;

public class App {

	public static void main(String[] args) {
		// Up = user position
		// tp = treasure position
		//Set up game
		User me = new User();
		Random rand = new Random();
		
		me.setUpX(2);
		me.setUpY(4);
		
		me.setTpX(3);
		me.setTpY(1);
		
		
		
		System.out.println(me.getCompass());
		
		me.moveSouth();
		
		
		System.out.println(me.getCompass());
		
		me.moveSouth();
		
		
		System.out.println(me.getCompass());
		
		me.moveSouth();
		
		
		System.out.println("Magic compass reads " + me.getCompass());
		
		me.moveEast();
		
		
		System.out.println(me.getCompass());
		
		
	}
}

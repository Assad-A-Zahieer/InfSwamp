import java.lang.Math;

abstract public class Position {
	
	private int tpX;
	private int tpY;
	private int upX;
	private int upY;
	private int compass;
	
	public int getTpX() {
		return tpX;
	}


	public void setTpX(int tpX) {
		this.tpX = tpX;
	}


	public int getTpY() {
		return tpY;
	}


	public void setTpY(int tpY) {
		this.tpY = tpY;
	}


	public int getUpX() {
		return upX;
	}


	public void setUpX(int upX) {
		this.upX = upX;
	}


	public int getUpY() {
		return upY;
	}


	public void setUpY(int upY) {
		this.upY = upY;
	}


//	public void setCompass() {
//		this.compass = (int) Math.sqrt( ((getTpX() - getUpX()) * (getTpX() - getUpX())) + ((getTpY() - getUpY()) * (getTpY() - getUpY())) );
//	}
	
	public int getCompass() {
		this.compass = (int) Math.sqrt( ((getTpX() - getUpX()) * (getTpX() - getUpX())) + ((getTpY() - getUpY()) * (getTpY() - getUpY())) );
		return compass;
	}
	
	

}
	



public class User extends Position {

	
	public void moveNorth() {
		setUpY(getUpY() + 1);
	}
	
	public void moveSouth() {
		setUpY(getUpY() - 1);
	}
	
	public void moveEast() {
		setUpX(getUpX() + 1);
	}
	
	public void moveWest() {
		setUpX(getUpX() - 1);
	}
	
}

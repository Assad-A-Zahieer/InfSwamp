import java.util.Random;
import java.util.Scanner;

public class App2 {

	public static void main(String[] args) {
		// Up = user position
		// tp = treasure position
		// Set up game

		boolean inGame = true;
		GAME: while (inGame) {

			Random rand = new Random();
			Scanner sc = new Scanner(System.in);

			User me = new User();
			// player position
			me.setUpX(rand.nextInt(10));
			me.setUpY(rand.nextInt(10));
			// treasure position
			me.setTpX(rand.nextInt(10));
			me.setTpY(rand.nextInt(10));

			// Instructions
			System.out.println("\t ** Welcome To T.I.T.S or TITS For Short **");

			System.out.println("\t You are on an adventure to find a hidden treasure.");
			System.out.println("\t Navigate through The Infinite Tessellating Swamp and grasp the treasured TITS treasure.");
			System.out.println("\t Here's a magic compass to help you find it.");
			
			while (!(me.getCompass() == 0)) {
				System.out.println("\t Magic compass reads " + me.getCompass() + (" m"));
				String option = sc.nextLine();

				if (option.equals("north")) {
					me.moveNorth();
				} else if (option.equalsIgnoreCase("south")) {
					me.moveSouth();
				} else if (option.equalsIgnoreCase("east")) {
					me.moveEast();
				} else if (option.equalsIgnoreCase("west")) {
					me.moveWest();
				} else {
					System.out.println("Invalid Command");
					System.out.println("Please Enter a Valid Direction e.g. North");
					option = sc.nextLine();
					System.out.println("Magic compass reads " + me.getCompass());
				}

			}
			
			System.out.println("Congrats You Found The Treasure");
			System.out.println("Play Again: Yes/No");
			String option2 = "";
			while(!option2.equalsIgnoreCase("yes") && !option2.equalsIgnoreCase("no")) {
				option2 = sc.nextLine();
				
				if(option2.equalsIgnoreCase("yes")) {
					continue GAME;
				}
				else if(option2.equalsIgnoreCase("no")) {
					System.out.println("Thanks For Playing");
					break;
				}
				else {
					System.out.println("Invalid Input");
					System.out.println("Play Again, Enter Either: Yes OR No");
				}
			}
			
			break;
		}

	}

}


public class User extends Position {

	private String greeting;
	private String name;
	
	User(String name){
		this.name = name;
	}
	
	public void moveNorth() {
		setUpY(getUpY() + 1);
	}
	
	public void moveSouth() {
		setUpY(getUpY() - 1);
	}
	
	public void moveEast() {
		setUpX(getUpX() + 1);
	}
	
	public void moveWest() {
		setUpX(getUpX() - 1);
	}

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting() {
		this.greeting = "Hello Player";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
	
	
}
